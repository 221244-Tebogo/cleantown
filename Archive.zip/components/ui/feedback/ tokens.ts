export const COLORS = {
  primary:  "#72C55D",
  secondary:"#2A7390",
  accent:   "#F29118",
  text:     "#1C2630",
  white:    "#FFFFFF",
};

export const FONT = { family: "Poppins" };
