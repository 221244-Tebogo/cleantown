// Profile.tsx
import { doc, onSnapshot } from "firebase/firestore";
import React, { useEffect, useState } from "react";
import { useAuth } from "../context/auth"; // ✅
import { db } from "../firebase";
import { Card, H2, P, Screen } from "../src/ui";

export default function Profile() {
  const { user } = useAuth();               // ✅ get signed-in user
  const [profile, setProfile] = useState<any>(null);

  useEffect(() => {
    if (!user?.uid) return;
    const ref = doc(db, "users", user.uid);
    const unsub = onSnapshot(ref, (snap) => {
      if (snap.exists()) setProfile(snap.data());
      else setProfile({ displayName: user.displayName ?? user.uid, totalPoints: 0, streakDays: 0 });
    });
    return () => unsub();
  }, [user?.uid]);

  return (
    <Screen>
      <Card><H2>My Profile</H2></Card>
      <Card>
        <P>Name: {profile?.displayName ?? user?.displayName ?? user?.uid}</P>
        <P>Points: {Number(profile?.totalPoints ?? 0)}</P>
        <P>Streak: {Number(profile?.streakDays ?? 0)} days</P>
      </Card>
    </Screen>
  );
}
