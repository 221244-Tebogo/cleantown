import { doc, onSnapshot } from "firebase/firestore";
import { useEffect, useState } from "react";
import { useAuth } from "../context/auth";
import { db } from "../firebase";

export function useMyPoints() {
  const { user } = useAuth();
  const [points, setPoints] = useState<number>(0);

  useEffect(() => {
    if (!user?.uid) {
      setPoints(0);
      return;
    }
    const ref = doc(db, "users", user.uid);
    const unsub = onSnapshot(
      ref,
      (snap) => setPoints(Number(snap.data()?.totalPoints ?? 0)),
      (err) => console.warn("points listen error:", err)
    );
    return () => unsub();
  }, [user?.uid]);

  return points;
}
